# BDD + Gherkin → Pytest → Xray Demo (Final)

Regenerated package with fixes.
