# BDD + pytest Demo

Run `pip install -r requirements.txt` then `pytest -q`.
