
import pytest
from pytest_bdd import scenarios, given, when, then, parsers
from app.calculator import add

scenarios('../features/add_numbers.feature')

@pytest.fixture
def context():
    return {}

@given(parsers.parse("I have two numbers {a:d} and {b:d}"))
def numbers(context, a, b):
    context['a'] = a; context['b'] = b

@when("I add them")
def do_add(context):
    context['result'] = add(context['a'], context['b'])

@then(parsers.parse("the result should be {sum:d}"))
def check_sum(context, sum):
    assert context['result'] == sum
