
import pytest
from pytest_bdd import scenarios, given, when, then
from app.customer_api import CustomerApiStub

scenarios('../features/api_quality.feature')

@pytest.fixture
def api():
    return CustomerApiStub()

@pytest.fixture
def payload():
    return {}

@given("the customer API")
def api_given(api):
    pass

@when("I fetch the list of customers")
def fetch(api, payload):
    payload['customers'] = api.list_customers()

@then("each customer should have a valid id")
def valid_id(payload):
    for c in payload['customers']:
        assert isinstance(c['id'], int)

@then("each customer should have a non-empty name")
def non_empty_name(payload):
    for c in payload['customers']:
        assert c['name']

@then("each customer should have a non-null age")
def non_null_age(payload):
    for c in payload['customers']:
        assert c['age'] is not None

@then("each customer should have a non-empty email")
def non_empty_email(payload):
    for c in payload['customers']:
        assert c['email']
