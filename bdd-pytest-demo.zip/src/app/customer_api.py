
class CustomerApiStub:
    def get_customer(self, cid: int):
        data = {
            1: {"id": 1, "name": "Alice", "age": 30, "email": "alice@example.com"},
            2: {"id": 2, "name": "Bob", "age": 28, "email": "bob@example.com"},
            3: {"id": 3, "name": "", "age": None, "email": ""},
        }
        return data.get(cid, {"id": cid, "name": "", "age": None, "email": ""})
    def list_customers(self):
        return [self.get_customer(i) for i in (1,2,3)]
