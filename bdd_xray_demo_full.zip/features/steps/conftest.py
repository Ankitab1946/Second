import pandas as pd
from pathlib import Path
import pytest
from sqlalchemy import create_engine

from app.config import load_config

@pytest.fixture(scope="session")
def cfg():
  return load_config()

@pytest.fixture(scope="session")
def reports_dir(cfg):
  p = Path(cfg["reports"]["base_dir"]); p.mkdir(parents=True, exist_ok=True)
  Path(cfg["reports"]["screenshots_dir"]).mkdir(parents=True, exist_ok=True)
  Path(cfg["reports"]["ge_docs"]).mkdir(parents=True, exist_ok=True)
  return p

@pytest.fixture(scope="session")
def db_engine(cfg):
  if cfg["db"]["engine"] == "sqlite":
    db_path = Path(cfg["db"]["sqlite"]["path"]); db_path.parent.mkdir(parents=True, exist_ok=True)
    return create_engine(f"sqlite:///{db_path}")
  else:
    import urllib.parse
    dsn = cfg["db"]["mssql"].get("dsn") or ""
    conn_str = cfg["db"]["mssql"].get("connection_string")
    if dsn:
      conn = f"mssql+pyodbc:///?odbc_connect=DSN={dsn}"
    else:
      conn = "mssql+pyodbc:///?odbc_connect=" + urllib.parse.quote_plus(conn_str)
    return create_engine(conn, fast_executemany=True)
