import pandas as pd
from pathlib import Path
from pytest_bdd import scenarios, given, when, then, parsers
from sqlalchemy import text

scenarios("../feed_db.feature")

@given(parsers.parse('a CSV feed "{feed_path}"'))
def feed_df(feed_path):
  p = Path(feed_path); assert p.exists(), f"{p} missing"
  return pd.read_csv(p)

@given(parsers.parse('a database table "{table}"'))
def ensure_table(db_engine, table):
  with db_engine.begin() as con:
    try:
      con.exec_driver_sql(f"DROP TABLE IF EXISTS {table}")
    except Exception:
      pass
    con.exec_driver_sql(f"CREATE TABLE {table} (id INTEGER, name TEXT, amount REAL)")
  return table

@when("I load the feed into the table")
def load_feed(feed_df, ensure_table, db_engine):
  feed_df.to_sql(ensure_table, db_engine, if_exists="append", index=False)

@then("the number of rows in the feed equals the number of rows in the table")
def count_parity(feed_df, ensure_table, db_engine):
  with db_engine.begin() as con:
    n = con.execute(text(f"SELECT COUNT(*) FROM {ensure_table}")).scalar()
  assert len(feed_df)==n, f"Feed {len(feed_df)} vs Table {n}"

@then(parsers.parse('column "{col}" has type "{expected}"'))
def type_check(ensure_table, db_engine, col, expected):
  with db_engine.begin() as con:
    try:
      rows = con.exec_driver_sql(f"PRAGMA table_info({ensure_table})").fetchall()
      d = {r[1]: r[2] for r in rows}
      actual = d[col]
    except Exception:
      q = f"SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='{ensure_table}' AND COLUMN_NAME='{col}'"
      actual = con.execute(text(q)).scalar()
  assert expected.lower() in str(actual).lower()
