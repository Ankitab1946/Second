import requests
from pathlib import Path
from pytest_bdd import scenarios, given, when, then, parsers
import great_expectations as ge
import pandas as pd

scenarios("../api_quality.feature")

@given(parsers.parse('a mock API at "{path}"'))
def api_url(cfg, path):
  return cfg["services"]["api_base"].rstrip("/") + path

@when("I fetch the JSON")
def api_json(api_url):
  r = requests.get(api_url, timeout=10)
  r.raise_for_status()
  return r.json()

@then(parsers.parse('the field "score" should be between 0 and 100'))
def ge_validate_score(api_json, cfg):
  df = pd.DataFrame([api_json])
  ge_df = ge.from_pandas(df)
  res = ge_df.expect_column_values_to_be_between("score", min_value=0, max_value=100)
  assert res.success, f"Score out of range: {df['score'].iloc[0]}"
  # Write a minimal Data Docs placeholder
  docs_dir = Path(cfg["reports"]["ge_docs"]); docs_dir.mkdir(parents=True, exist_ok=True)
  (docs_dir/"index.html").write_text("<html><body><h1>GE Data Docs</h1><p>Score check passed.</p></body></html>", encoding="utf-8")

@then("I persist Great Expectations Data Docs")
def no_op():
  pass
