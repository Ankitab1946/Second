# BDD + Gherkin → Pytest → Xray (End-to-End Demo)

Production-ready demo: Enter plain English → Bedrock (Claude) generates **Gherkin** → save `.feature` → **pytest-bdd** runs DB/API/UI tests → **reports** (Cucumber JSON, Allure, HTML, screenshots) → push to **Xray/Jira** → deep links. Includes SQLite default + MSSQL option, Great Expectations, Selenium, and FastAPI mock services.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# start mock services in two shells
uvicorn mock_services.api_server:app --reload --port 8001
uvicorn mock_services.web_server:app --reload --port 8002

# run UI
streamlit run app/ui.py
```

## Optional: Bedrock (EN→Gherkin)
Set `.env` or shell:
```
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20240620-v1:0
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_SESSION_TOKEN=...
```
> If model access fails, the app **falls back** to a local Gherkin template so the end‑to‑end flow still works.

## Xray/Jira
Edit `.env`:
```
XRAY_TYPE=cloud
XRAY_CLIENT_ID=...
XRAY_CLIENT_SECRET=...
XRAY_CLOUD_BASE=https://xray.cloud.getxray.app
JIRA_BASE=https://your-domain.atlassian.net
JIRA_USER_EMAIL=you@company.com
JIRA_API_TOKEN=...
```
For Server/DC, see `.env.example` and README sections in the previous message.

## Run pytest directly
```bash
pytest -q --cucumberjson=reports/report.json --alluredir=reports/allure --html=reports/pytest_html/index.html --self-contained-html
```

Artifacts: `reports/report.json`, `reports/allure/`, `reports/pytest_html/index.html`, `reports/screenshots/`, `reports/ge_data_docs/`, summary in `reports/summary/`.
