from pathlib import Path
import json, subprocess
from jinja2 import Template
from app.config import load_config

TEMPLATE = """<!doctype html><html><head><meta charset="utf-8"><title>Test Execution Summary</title></head>
<body>
<h1>Test Execution Summary</h1>
<p><strong>Total:</strong> {{ total }} | <strong>Passed:</strong> {{ passed }} | <strong>Failed:</strong> {{ failed }}</p>
<h2>Scenarios</h2>
<ol>
{% for s in scenarios %}
<li><strong>{{ s.name }}</strong> — <em>{{ s.status }}</em> <small>({{ s.uri }}:{{ s.line }})</small></li>
{% endfor %}
</ol>
<h2>Artifacts</h2>
<ul>
<li>Cucumber JSON: {{ cucumber }}</li>
<li>Allure dir: {{ allure }}</li>
<li>HTML report: {{ html }}</li>
<li>Screenshots: {{ screenshots }}</li>
<li>GE Data Docs: {{ ge_docs }}</li>
</ul>
</body></html>
"""

def _parse_cucumber(cucumber_path: Path):
  if not cucumber_path.exists(): return [], 0, 0
  data = json.loads(cucumber_path.read_text(encoding='utf-8') or '[]')
  scenarios, passed, failed = [], 0, 0
  for feature in data:
    for el in feature.get('elements', []):
      name = el.get('name','')
      status = 'passed'
      for st in el.get('steps', []):
        rs = st.get('result',{}).get('status')
        if rs in ('failed','skipped','undefined'):
          status = rs; break
      passed += 1 if status=='passed' else 0
      failed += 1 if status!='passed' else 0
      scenarios.append({'name':name,'status':status,'uri':feature.get('uri',''),'line':el.get('line',0)})
  return scenarios, passed, failed

def build_execution_summary():
  cfg = load_config()
  rep = Path(cfg['reports']['base_dir']); rep.mkdir(parents=True, exist_ok=True)
  cucumber = rep/'report.json'
  scenarios, passed, failed = _parse_cucumber(cucumber)
  total = passed + failed
  html = Template(TEMPLATE).render(
    total=total, passed=passed, failed=failed, scenarios=scenarios,
    cucumber=str(cucumber), allure=cfg['reports']['allure_dir'],
    html=cfg['reports']['html_dir']+'/index.html',
    screenshots=cfg['reports']['screenshots_dir'],
    ge_docs=cfg['reports']['ge_docs']
  )
  out_dir = rep/'summary'; out_dir.mkdir(parents=True, exist_ok=True)
  html_path = out_dir/'TestExecutionSummary.html'
  html_path.write_text(html, encoding='utf-8')
  # Optional PDF via wkhtmltopdf
  pdf_path = None
  try:
    pdf_candidate = out_dir/'TestExecutionSummary.pdf'
    subprocess.run(['wkhtmltopdf', str(html_path), str(pdf_candidate)], check=True)
    if pdf_candidate.exists(): pdf_path = pdf_candidate
  except Exception:
    pdf_path = None
  return str(html_path), (str(pdf_path) if pdf_path else None)
