from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Mock API")

class Score(BaseModel):
  id: int
  score: float

@app.get("/score/{item_id}", response_model=Score)
def get_score(item_id: int):
  val = (item_id * 13) % 101
  return {"id": item_id, "score": float(val)}
