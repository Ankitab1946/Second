using System;
using System.Threading.Tasks;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
using System.Data;

namespace ExcelFinanceAddIn
{
    public partial class RibbonFinance
    {
        private void RibbonFinance_Load(object sender, RibbonUIEventArgs e)
        {
        }

        private void btnSnowflake_Click(object sender, RibbonControlEventArgs e)
        {
            try
            {
                var dt = Data.SnowflakeHelper.GetBalanceSheet();
                Utils.ExcelWriter.WriteToExcel(dt, "Snowflake Balance Sheet");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Snowflake Error: {ex.Message}");
            }
        }

        private async void btnApi_Click(object sender, RibbonControlEventArgs e)
        {
            try
            {
                var dt = await Data.ApiHelper.GetBalanceSheetFromApiAsync();
                Utils.ExcelWriter.WriteToExcel(dt, "API Balance Sheet");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"API Error: {ex.Message}");
            }
        }

        private void btnSqlServer_Click(object sender, RibbonControlEventArgs e)
        {
            try
            {
                var dt = Data.SqlServerHelper.GetBalanceSheet();
                Utils.ExcelWriter.WriteToExcel(dt, "SQL Server Balance Sheet");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL Error: {ex.Message}");
            }
        }
    }
}
