using System.Data;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelFinanceAddIn.Utils
{
    public static class ExcelWriter
    {
        public static void WriteToExcel(DataTable data, string sheetName)
        {
            var xlApp = Globals.ThisAddIn.Application as Excel.Application;
            Excel.Worksheet ws = null;

            try
            {
                // Try to find existing sheet
                foreach (Excel.Worksheet s in xlApp.Worksheets)
                {
                    if (s.Name == sheetName) { ws = s; break; }
                }
            }
            catch { }

            if (ws == null)
            {
                ws = xlApp.Worksheets.Add();
                ws.Name = sheetName;
            }

            // Clear sheet
            ws.Cells.Clear();

            // Write headers
            for (int c = 0; c < data.Columns.Count; c++)
            {
                ws.Cells[1, c + 1] = data.Columns[c].ColumnName;
            }

            // Write rows
            for (int r = 0; r < data.Rows.Count; r++)
            {
                for (int c = 0; c < data.Columns.Count; c++)
                {
                    ws.Cells[r + 2, c + 1] = data.Rows[r][c];
                }
            }

            // Format header
            Excel.Range header = ws.Range[ws.Cells[1, 1], ws.Cells[1, data.Columns.Count]];
            header.Font.Bold = true;
            header.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(198, 239, 206));

            // Auto fit
            ws.Columns.AutoFit();

            // Freeze header
            xlApp.ActiveWindow.SplitRow = 1;
            xlApp.ActiveWindow.FreezePanes = true;
        }
    }
}
