namespace ExcelFinanceAddIn
{
    partial class RibbonFinance : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        private System.ComponentModel.IContainer components = null;
        public RibbonFinance() : base(Globals.Factory.GetRibbonFactory()) => InitializeComponent();

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        private void InitializeComponent()
        {
            this.tabFinance = this.Factory.CreateRibbonTab();
            this.groupDataFetch = this.Factory.CreateRibbonGroup();
            this.btnSnowflake = this.Factory.CreateRibbonButton();
            this.btnApi = this.Factory.CreateRibbonButton();
            this.btnSqlServer = this.Factory.CreateRibbonButton();
            this.tabFinance.SuspendLayout();
            this.groupDataFetch.SuspendLayout();
            this.SuspendLayout();

            this.tabFinance.Label = "Finance Tools";
            this.tabFinance.Groups.Add(this.groupDataFetch);

            this.groupDataFetch.Label = "Data Fetch";
            this.groupDataFetch.Items.Add(this.btnSnowflake);
            this.groupDataFetch.Items.Add(this.btnApi);
            this.groupDataFetch.Items.Add(this.btnSqlServer);

            this.btnSnowflake.Label = "Fetch from Snowflake";
            this.btnSnowflake.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnSnowflake_Click);

            this.btnApi.Label = "Fetch from API";
            this.btnApi.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnApi_Click);

            this.btnSqlServer.Label = "Fetch from SQL Server";
            this.btnSqlServer.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnSqlServer_Click);

            this.Name = "RibbonFinance";
            this.RibbonType = "Microsoft.Excel.Workbook";
            this.Tabs.Add(this.tabFinance);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.RibbonFinance_Load);

            this.tabFinance.ResumeLayout(false);
            this.groupDataFetch.ResumeLayout(false);
            this.ResumeLayout(false);
        }
        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tabFinance;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup groupDataFetch;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnSnowflake;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnApi;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnSqlServer;
    }
}
