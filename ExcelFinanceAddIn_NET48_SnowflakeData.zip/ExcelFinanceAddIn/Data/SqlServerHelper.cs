using System.Data;
using System.Data.SqlClient;

namespace ExcelFinanceAddIn.Data
{
    public static class SqlServerHelper
    {
        public static DataTable GetBalanceSheet()
        {
            string connStr = "Server=YOUR_SERVER;Database=FinanceDB;Integrated Security=True;";
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                var query = "SELECT Year, Account, Amount FROM dbo.BalanceSheet ORDER BY Year DESC";
                using (var da = new SqlDataAdapter(query, conn))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }
    }
}
