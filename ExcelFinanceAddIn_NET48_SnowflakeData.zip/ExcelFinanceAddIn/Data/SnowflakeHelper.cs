using System;
using System.Data;
using Snowflake.Data.Client; // Using Snowflake.Data ADO.NET driver (manual DLL reference required)
// using System.Data.Odbc;

namespace ExcelFinanceAddIn.Data
{
    public static class SnowflakeHelper
    {
        public static DataTable GetBalanceSheet()
        {
            string connStr = "account=YOUR_ACCOUNT;user=YOUR_USER;password=YOUR_PASS;db=YOUR_DB;schema=PUBLIC;warehouse=COMPUTE_WH;";
            using (var conn = new SnowflakeDbConnection())
            {
                conn.ConnectionString = connStr;
                conn.Open();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT Year, Account, Amount FROM BALANCE_SHEET ORDER BY Year DESC";
                    using (var reader = cmd.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        return dt;
                    }
                }
            }
        }
    }
}
