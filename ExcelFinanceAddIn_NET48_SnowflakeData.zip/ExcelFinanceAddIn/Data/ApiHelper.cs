using System.Data;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ExcelFinanceAddIn.Data
{
    public static class ApiHelper
    {
        public static async Task<DataTable> GetBalanceSheetFromApiAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new System.Uri("https://api.yourcompany.com/");
                var resp = await client.GetAsync("balancesheet");
                resp.EnsureSuccessStatusCode();
                string json = await resp.Content.ReadAsStringAsync();
                var dt = JsonConvert.DeserializeObject<DataTable>(json);
                return dt;
            }
        }
    }
}
