# ExcelFinanceAddIn (NET 4.8) - Snowflake.Data ADO.NET edition

This is a ready-to-build Visual Studio VSTO Excel Add-in project targeting **.NET Framework 4.8** and configured to use the **Snowflake.Data ADO.NET driver** (manual DLL reference required), plus REST API and SQL Server fetch examples.

## Important notes before building

### 1) Snowflake.Data (manual step required)
- Due to NuGet dependency issues with newer Snowflake.Data packages, this project expects you to **manually add** the `Snowflake.Data.dll` compiled for .NET Framework (v2.x series).
- Download the Snowflake.Data `.nupkg` (for example v2.2.1) from https://www.nuget.org/packages/Snowflake.Data/2.2.1
- Extract the `.nupkg` (it's a zip). Locate `lib/net45` or `lib/net46` and copy `Snowflake.Data.dll` into the `lib` folder of your project or a `libs` folder.
- In Visual Studio: **Project → Add Reference → Browse** and select the `Snowflake.Data.dll`.
- If prompted about AWSSDK.S3 dependency, you can:
  - Install a compatible `AWSSDK.S3` NuGet package, or
  - If you don't use PUT/GET (staging) features, ignore dependencies and just reference the DLL.

### 2) Configure connection strings
- Edit `Data/SnowflakeHelper.cs` and replace `YOUR_ACCOUNT`, `YOUR_USER`, `YOUR_PASS`, `YOUR_DB`, `COMPUTE_WH` with your Snowflake credentials.
- Edit `Data/SqlServerHelper.cs` and replace `YOUR_SERVER` and database as required.
- Edit `Data/ApiHelper.cs` with your API base URL.

### 3) Build & Run
- Open the solution in Visual Studio (on a machine with Office/Excel installed).
- Restore NuGet packages (Newtonsoft.Json).
- Add manual Snowflake.Data.dll reference as described above.
- Build and press F5 — Visual Studio will launch Excel with the Add-in loaded.

## Files included
- ThisAddIn.cs
- RibbonFinance.cs / RibbonFinance.Designer.cs
- Data/SnowflakeHelper.cs (uses Snowflake.Data ADO.NET)
- Data/SqlServerHelper.cs
- Data/ApiHelper.cs
- Utils/ExcelWriter.cs
- README.md

