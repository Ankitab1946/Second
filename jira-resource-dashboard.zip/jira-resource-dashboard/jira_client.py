
import requests
from requests.auth import HTTPBasicAuth
import pandas as pd

class JiraClient:
    def __init__(self, base_url, email, api_token):
        self.base_url = base_url.rstrip("/")
        self.auth = HTTPBasicAuth(email, api_token)
        self.headers = {"Accept": "application/json"}

    def _get(self, endpoint, params=None):
        url = f"{self.base_url}/rest/api/3/{endpoint}"
        response = requests.get(url, headers=self.headers, auth=self.auth, params=params)
        if response.status_code != 200:
            raise Exception(f"Jira API Error: {response.text}")
        return response.json()

    def get_projects(self):
        data = self._get("project")
        return pd.DataFrame([{"id": p["id"], "key": p["key"], "name": p["name"]} for p in data])

    def search_issues(self, jql):
        url = f"{self.base_url}/rest/api/3/search"
        response = requests.get(url, headers=self.headers, auth=self.auth,
                                params={"jql": jql, "maxResults": 1000})
        return response.json()["issues"]

    def get_worklogs(self, issue_key):
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}/worklog"
        response = requests.get(url, headers=self.headers, auth=self.auth)
        return response.json()["worklogs"]
