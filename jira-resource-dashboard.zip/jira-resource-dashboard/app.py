
import streamlit as st
import pandas as pd
from jira_client import JiraClient
from metrics import calculate_story_points, calculate_worklog
from charts import *

st.set_page_config(page_title="Jira Resource Dashboard", layout="wide")
st.title("📊 Jira Resource Performance Dashboard")

st.sidebar.header("🔧 Jira Configuration")

base_url = st.sidebar.text_input("Jira Base URL")
email = st.sidebar.text_input("Email")
api_token = st.sidebar.text_input("API Token", type="password")

if st.sidebar.button("Connect"):
    client = JiraClient(base_url, email, api_token)
    st.session_state["client"] = client

if "client" in st.session_state:
    client = st.session_state["client"]
    projects = client.get_projects()
    project = st.sidebar.selectbox("Project", projects["key"])

    jql = f'project = {project}'
    issues = client.search_issues(jql)

    df_sp = calculate_story_points(issues)

    st.subheader("📌 Story Points Overview")
    st.dataframe(df_sp)

    st.plotly_chart(bar_assigned_vs_completed(df_sp), use_container_width=True)
    st.plotly_chart(stacked_spillover(df_sp), use_container_width=True)
    st.plotly_chart(pie_sp_distribution(df_sp), use_container_width=True)

    st.subheader("⏱ Worklog Summary")
    df_work = calculate_worklog(client, issues, None, None)
    st.dataframe(df_work)
