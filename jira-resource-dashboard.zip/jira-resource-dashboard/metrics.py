
import pandas as pd

def calculate_story_points(issues):
    records = []
    for issue in issues:
        assignee = issue["fields"]["assignee"]
        assignee_name = assignee["displayName"] if assignee else "Unassigned"
        sp = issue["fields"].get("customfield_10016", 0) or 0
        status = issue["fields"]["status"]["name"]

        records.append({
            "assignee": assignee_name,
            "story_points": sp,
            "status": status
        })

    df = pd.DataFrame(records)

    grouped = df.groupby("assignee").agg(
        assigned_sp=("story_points", "sum")
    ).reset_index()

    completed = df[df["status"] == "Done"].groupby("assignee")["story_points"].sum().reset_index()
    completed.columns = ["assignee", "completed_sp"]

    grouped = grouped.merge(completed, on="assignee", how="left").fillna(0)
    grouped["spillover_sp"] = grouped["assigned_sp"] - grouped["completed_sp"]
    grouped["completion_%"] = (grouped["completed_sp"] / grouped["assigned_sp"]) * 100

    return grouped

def calculate_worklog(client, issues, start_date, end_date):
    data = []
    for issue in issues:
        worklogs = client.get_worklogs(issue["key"])
        for wl in worklogs:
            author = wl["author"]["displayName"]
            time_spent = wl["timeSpentSeconds"] / 3600
            data.append({"author": author, "hours": time_spent})

    df = pd.DataFrame(data)
    if df.empty:
        return df

    return df.groupby("author").agg(total_hours=("hours", "sum")).reset_index()
