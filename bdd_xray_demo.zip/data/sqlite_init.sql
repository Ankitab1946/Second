
-- Creates demo table and loads data from CSV using pandas in test fixture (see conftest.py).
