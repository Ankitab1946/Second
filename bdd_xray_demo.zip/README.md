# BDD + Gherkin → Pytest → Xray (End-to-End Demo)

This is a production-ready demo showing how to turn plain-English requirements into runnable BDD tests (via AWS Bedrock → Gherkin), execute them with **pytest-bdd**, generate reports (Allure + Cucumber JSON), capture **Selenium** screenshots, validate data with **Great Expectations**, and push results to **Jira Xray**.

## Stack
- Python 3.11
- Streamlit UI
- AWS Bedrock (Anthropic Claude via `boto3`) → **anthropic_version: bedrock-2023-05-31**
- pytest, pytest-bdd
- Selenium (Chrome) with webdriver-manager
- SQLite (default) + optional SQL Server (pyodbc, Windows Auth)
- FastAPI mock API + demo Web page
- Great Expectations (programmatic suite & Data Docs)
- Xray/Jira REST API (Cloud or Server/DC), Cucumber JSON import, attach screenshots
- Allure reports + HTML report

## Quick start (local demo on SQLite)
```bash
# 0) Python 3.11 and Chrome installed.
# 1) Create & activate venv
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install deps
pip install -r requirements.txt

# 3) (Optional) Set Bedrock env if you want EN->Gherkin via Claude:
# export AWS_ACCESS_KEY_ID=...
# export AWS_SECRET_ACCESS_KEY=...
# export AWS_SESSION_TOKEN=...
# export AWS_REGION=us-east-1

# 4) Start mock services (API + Demo web page) in separate shells
uvicorn mock_services.api_server:app --reload --port 8001
uvicorn mock_services.web_server:app --reload --port 8002

# 5) Launch Streamlit UI
streamlit run app/ui.py
```

The UI lets you:
- Enter plain English → calls Bedrock → saves `.feature` under `features/`
- Preview/save feature files
- **Run Pytest Now**: executes all scenarios, shows live results, links screenshots
- Generate **Cucumber JSON** (`reports/report.json`) and **Allure** results
- Upload to **Xray** from UI and get the **Test Execution** key + Jira deep links
- Download **Test Execution Summary** (HTML, plus optional PDF if wkhtmltopdf available)

## SQL Server (optional)
In `config/config.yaml` set:
```yaml
db:
  engine: "mssql"   # default: sqlite
  mssql:
    dsn: ""         # DSN name (preferred) OR use connection_string below
    connection_string: "Driver={ODBC Driver 17 for SQL Server};Server=YOURSERVER;Database=YOURDB;Trusted_Connection=yes;"
```
Install ODBC driver and `pyodbc`. When `engine=mssql`, tests use SQL Server instead of SQLite.

## Xray / Jira
Set in `.env` or system env:
```
XRAY_TYPE=cloud            # or server
# For XRAY Cloud (recommended):
XRAY_CLIENT_ID=...
XRAY_CLIENT_SECRET=...
XRAY_CLOUD_BASE=https://xray.cloud.getxray.app
JIRA_BASE=https://your-domain.atlassian.net
JIRA_USER_EMAIL=you@company.com
JIRA_API_TOKEN=your_jira_api_token

# For Server/DC:
JIRA_BASE=https://jira.yourcompany.com
JIRA_USER=you
JIRA_PASSWORD=******
XRAY_SERVER_IMPORT=/rest/raven/1.0/import/execution/cucumber/multipart
```

## Reports & Artifacts
- **Cucumber JSON**: `reports/report.json`
- **Allure**: `reports/allure/`
- **HTML Test Report**: `reports/pytest_html/index.html`
- **Screenshots**: `reports/screenshots/`
- **GE Data Docs**: `reports/ge_data_docs/`
- **Summary (HTML/PDF)**: `reports/summary/TestExecutionSummary.html` (+ PDF if available)

---

## Scenarios implemented
1. **Feed → DB** (SQLite default; switchable to SQL Server)
   - Row count parity between feed CSV and DB table
   - Data type verification on key columns

2. **API Data Quality** (Great Expectations)
   - Mock API with numeric `score`
   - Expectation: `0 <= score <= 100` (Data Docs persisted)

3. **UI Validation** (Selenium/Chrome)
   - Demo web page lists clients & revenue
   - Assert Client A's revenue equals expected

4. **Parameterisation Example** (Scenario Outline)

---

## Running pytest directly (without UI)
```bash
pytest -q --cucumberjson=reports/report.json --alluredir=reports/allure --html=reports/pytest_html/index.html --self-contained-html
```

## PDF rendering (optional)
If `wkhtmltopdf` is installed and on PATH, the UI will also generate a PDF from the Summary HTML.

## Notes
- Make sure Chrome is installed; `webdriver-manager` auto-downloads driver.
- On corporate networks, set proxies as needed.
- For Bedrock access, ensure permissions to invoke the selected Anthropic model and region.
