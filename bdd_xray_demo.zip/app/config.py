
import yaml
from pathlib import Path

def load_config():
    p = Path("config/config.yaml")
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)
