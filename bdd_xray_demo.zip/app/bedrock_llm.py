
import os, json
import boto3

MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0")
ANTHROPIC_VERSION = "bedrock-2023-05-31"

PROMPT = """You are an expert BDD analyst. Convert the user's plain-English software requirement into clean, valid Gherkin using pytest-bdd style.
- Use Feature/Scenario/Scenario Outline, Given/When/Then.
- Keep steps atomic; avoid UI details unless required.
- Do not add code. Output only Gherkin.
"""

def english_to_gherkin(plain_english: str) -> str:
    if not plain_english or not plain_english.strip():
        raise ValueError("Empty input")
    client = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION", "us-east-1"))
    body = {
        "anthropic_version": ANTHROPIC_VERSION,
        "max_tokens": 800,
        "messages": [
            {"role":"user","content":[{"type":"text","text": PROMPT + "\n\nRequirement:\n" + plain_english}]}
        ]
    }
    resp = client.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body).encode("utf-8"),
        accept="application/json",
        contentType="application/json"
    )
    payload = json.loads(resp["body"].read())
    # Claude returns content list with text
    text = "".join(block.get("text","") for block in payload.get("content",[]) if block.get("type")=="text")
    return text.strip()
