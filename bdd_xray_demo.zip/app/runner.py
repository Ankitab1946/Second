
import subprocess, os, json
from pathlib import Path
from app.config import load_config

def run_pytest_and_collect():
    cfg = load_config()
    reports = cfg["reports"]
    base = Path(reports["base_dir"]); base.mkdir(exist_ok=True, parents=True)
    allure = Path(reports["allure_dir"]); allure.mkdir(parents=True, exist_ok=True)
    html_dir = Path(reports["html_dir"]); html_dir.mkdir(parents=True, exist_ok=True)
    ss_dir = Path(reports["screenshots_dir"]); ss_dir.mkdir(parents=True, exist_ok=True)
    cucumber = base / "report.json"

    cmd = [
        "pytest",
        "-q",
        f"--cucumberjson={cucumber}",
        f"--alluredir={allure}",
        f"--html={html_dir/'index.html'}",
        "--self-contained-html",
    ]
    env = os.environ.copy()
    proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
    return {
        "returncode": proc.returncode,
        "stdout": proc.stdout[-10_000:],
        "stderr": proc.stderr[-10_000:],
        "cucumber": str(cucumber),
        "allure_dir": str(allure),
        "html_report": str(html_dir / "index.html"),
        "screenshots_dir": str(ss_dir),
    }
