
import os, json, time, base64, requests
from pathlib import Path

class XrayClient:
    def __init__(self):
        self.xray_type = os.getenv("XRAY_TYPE","cloud").lower()
        self.jira_base = os.getenv("JIRA_BASE","").rstrip("/")
        self.cloud_base = os.getenv("XRAY_CLOUD_BASE","https://xray.cloud.getxray.app").rstrip("/")
        self.client_id = os.getenv("XRAY_CLIENT_ID","")
        self.client_secret = os.getenv("XRAY_CLIENT_SECRET","")
        self.jira_user_email = os.getenv("JIRA_USER_EMAIL","")
        self.jira_api_token = os.getenv("JIRA_API_TOKEN","")
        self.jira_user = os.getenv("JIRA_USER","")
        self.jira_password = os.getenv("JIRA_PASSWORD","")

    def _cloud_token(self):
        url = f"{self.cloud_base}/api/v2/authenticate"
        r = requests.post(url, json={"client_id": self.client_id, "client_secret": self.client_secret})
        r.raise_for_status()
        return r.json()

    def jira_issue_url(self, key: str) -> str:
        return f"{self.jira_base}/browse/{key}"

    def import_cucumber_and_get_keys(self, cucumber_path: Path, project_key: str, summary: str):
        if self.xray_type == "cloud":
            token = self._cloud_token()
            url = f"{self.cloud_base}/api/v2/import/execution/cucumber/multipart"
            files = {
                "file": ("report.json", open(cucumber_path, "rb"), "application/json"),
                "info": (None, json.dumps({"fields": {"project": {"key": project_key}, "summary": summary}}), "application/json"),
            }
            headers = {"Authorization": f"Bearer {token}"}
            resp = requests.post(url, headers=headers, files=files)
            resp.raise_for_status()
            data = resp.json()
            te_key = data.get("key") or data.get("testExecIssue",{}).get("key")
            test_keys = [t.get("testKey") for t in data.get("tests",[]) if t.get("testKey")]
            return te_key, test_keys
        else:
            # Server/DC (basic auth)
            url = f"{self.jira_base}{os.getenv('XRAY_SERVER_IMPORT','/rest/raven/1.0/import/execution/cucumber/multipart')}"
            files = {
                "file": ("report.json", open(cucumber_path, "rb"), "application/json"),
                "info": (None, json.dumps({"fields": {"project": {"key": project_key}, "summary": summary}}), "application/json"),
            }
            resp = requests.post(url, auth=(self.jira_user, self.jira_password), files=files)
            resp.raise_for_status()
            data = resp.json()
            te_key = data.get("testExecIssue",{}).get("key")
            return te_key, []

    def attach_files_to_issue(self, issue_key: str, file_paths):
        if not issue_key or not file_paths:
            return
        url = f"{self.jira_base}/rest/api/3/issue/{issue_key}/attachments"
        headers = {"X-Atlassian-Token": "no-check"}
        auth = (self.jira_user_email, self.jira_api_token) if self.xray_type=="cloud" else (self.jira_user, self.jira_password)
        files = [("file", (Path(p).name, open(p, "rb"), "image/png")) for p in file_paths]
        r = requests.post(url, headers=headers, auth=auth, files=files)
        r.raise_for_status()
