
import os, json, subprocess, base64, webbrowser, shutil
from pathlib import Path
import streamlit as st
from dotenv import load_dotenv
from app.config import load_config
from app.bedrock_llm import english_to_gherkin
from app.runner import run_pytest_and_collect
from app.xray_client import XrayClient
from app.summary import build_execution_summary

load_dotenv()
cfg = load_config()

st.set_page_config(page_title="BDD → Pytest → Xray Demo", layout="wide")

st.title("🧪 BDD + Gherkin → Pytest → Xray (End-to-End Demo)")

# Section: English → Gherkin
st.header("1) Convert Plain English to Gherkin via Bedrock (Anthropic)")
plain = st.text_area("Describe your requirement in simple English", height=160, placeholder="Example: Ensure feed CSV rows match DB table rows and data types are correct...")
col1, col2 = st.columns([1,1])

with col1:
    file_name = st.text_input("Feature file name (without extension)", value="generated_requirement")

with col2:
    if st.button("Convert to Gherkin & Save"):
        try:
            gherkin = english_to_gherkin(plain)
            features_dir = Path("features")
            features_dir.mkdir(exist_ok=True)
            feature_path = features_dir / f"{file_name}.feature"
            feature_path.write_text(gherkin, encoding="utf-8")
            st.success(f"Saved: {feature_path}")
            st.code(gherkin, language="gherkin")
        except Exception as e:
            st.error(f"Error generating Gherkin: {e}")

# Section: Run Pytest
st.header("2) Run Pytest Now")
run = st.button("▶ Run all BDD tests")
if run:
    try:
        results = run_pytest_and_collect()
        st.success("Pytest finished")
        st.json(results)
        # Links
        rep_base = Path(cfg['reports']['base_dir'])
        st.markdown(f"- **Cucumber JSON**: `{rep_base/'report.json'}`")
        st.markdown(f"- **Allure dir**: `{cfg['reports']['allure_dir']}`")
        st.markdown(f"- **HTML report**: `{cfg['reports']['html_dir']}/index.html`")
        st.markdown(f"- **Screenshots**: `{cfg['reports']['screenshots_dir']}`")
        st.markdown(f"- **GE Data Docs**: `{cfg['reports']['ge_docs']}`")
    except Exception as e:
        st.error(f"Run failed: {e}")

# Section: Upload to Xray
st.header("3) Upload Result to Xray & Show Links")
project_key = st.text_input("Jira Project Key", value="DEMO")
test_exec_summary = st.text_input("Test Execution Summary", value="Automated run from Streamlit UI")
if st.button("⬆ Upload to Xray"):
    try:
        client = XrayClient()
        cucumber_path = Path(cfg['reports']['base_dir']) / "report.json"
        te_key, test_keys = client.import_cucumber_and_get_keys(cucumber_path, project_key, test_exec_summary)
        st.success(f"Uploaded. Test Execution: {te_key}")
        if te_key:
            st.markdown(f"[Open Test Execution in Jira]({client.jira_issue_url(te_key)})")
        if test_keys:
            st.write("Test issues:")
            for k in test_keys[:15]:
                st.markdown(f"- [{k}]({client.jira_issue_url(k)})")
        # Attach screenshots to Test Execution
        ss_dir = Path(cfg['reports']['screenshots_dir'])
        if ss_dir.exists():
            client.attach_files_to_issue(te_key, list(ss_dir.glob('*.png'))[:20])
            st.info("Attached up to 20 screenshots to Test Execution.")
    except Exception as e:
        st.error(f"Xray upload failed: {e}")

# Section: Build Summary
st.header("4) Download Test Execution Summary (HTML/PDF)")
if st.button("📝 Build Summary Now"):
    try:
        html_path, pdf_path = build_execution_summary()
        st.success("Summary built")
        st.markdown(f"[Open HTML Summary]({html_path})")
        if pdf_path:
            st.markdown(f"[Download PDF]({pdf_path})")
    except Exception as e:
        st.error(f"Summary failed: {e}")
