
from pytest_bdd import scenarios, given, when, then, parsers
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from pathlib import Path
import time

scenarios("../ui_revenue.feature")
scenarios("../outlines.feature")

def _driver():
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    return webdriver.Chrome(ChromeDriverManager().install(), options=opts)

@given("the demo web page is running")
def base_url(cfg):
    return cfg["services"]["web_base"]

@when("I open the page")
def open_page(base_url):
    driver = _driver()
    driver.get(base_url + "/")
    time.sleep(0.5)
    return driver

@then(parsers.parse('I see revenue "{expected}" for "{client}"'))
def assert_revenue(open_page, expected, client, cfg):
    driver = open_page
    try:
        # For Client A specifically, id is present; for others, scan table
        if client == "Client A":
            el = driver.find_element(By.ID, "client-a-revenue")
            value = el.text.strip()
        else:
            rows = driver.find_elements(By.CSS_SELECTOR, "#clients tr")
            value = None
            for r in rows:
                tds = r.find_elements(By.TAG_NAME, "td")
                if len(tds)==2 and tds[0].text.strip()==client:
                    value = tds[1].text.strip()
                    break
        assert value == expected, f"{client} revenue expected {expected} got {value}"
    finally:
        # Screenshot
        ss_dir = Path(cfg["reports"]["screenshots_dir"])
        ss_dir.mkdir(parents=True, exist_ok=True)
        driver.save_screenshot(str(ss_dir / f"{client.replace(' ','_')}.png"))
        driver.quit()
