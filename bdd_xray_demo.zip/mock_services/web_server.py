
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI(title="Demo Web App")

HTML = """
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Clients</title></head>
<body>
<h1>Client Revenues</h1>
<table id="clients">
<tr><th>Client</th><th>Revenue</th></tr>
<tr><td>Client A</td><td id="client-a-revenue">12345</td></tr>
<tr><td>Client B</td><td>9876</td></tr>
</table>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
def home():
    return HTML
